import time
from core.dbTesting import crear_nueva_prueba_bd
import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class IngresarProducto:
    def __init__(self):
        lista = login().inicioSistema('Ingresar producto', 'ingresarProducto')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot en la carpeta
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso al sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")

            # Interacción con la página del menú principal
            botonInventario = driver.find_element(By.XPATH, "//*[@id='app']/div/a[2]")
            botonInventario.click()
            logging.info("Botón 'Inventario' clicado.")

            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "/html/body/a[1]"))
            )
            logging.info("Vista de inventario cargada.")

            botonNuevoProducto = driver.find_element(By.XPATH, "/html/body/a[1]")
            botonNuevoProducto.click()
            logging.info("Botón 'Nuevo Producto' clicado.")

            screenshot_path = os.path.join(carpetaEvidencias, 'Vista de CrearNuevoProducto.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de la vista de inventario.")

            # Interacción con el formulario de creación de Producto
            producto = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//*[@id="producto"]'))
            )
            producto.send_keys(dataProvider[2])
            logging.info(f"Producto '{dataProvider[2]}' ingresado en el formulario.")

            marca = driver.find_element(By.XPATH, '//*[@id="marca"]')
            marca.send_keys(dataProvider[3])
            logging.info(f"Marca '{dataProvider[3]}' ingresado en el formulario.")

            valor = driver.find_element(By.XPATH, '//*[@id="valor"]')
            valor.send_keys(dataProvider[4])
            logging.info(f"Valor '{dataProvider[4]}' ingresada en el formulario.")

            precio = driver.find_element(By.XPATH, '//*[@id="precio"]')
            precio.send_keys(dataProvider[5])
            logging.info(f"Precio '{dataProvider[5]}' ingresado en el formulario.")

            cantidad = driver.find_element(By.XPATH, '//*[@id="cantidad"]')
            cantidad.send_keys(dataProvider[6])
            logging.info(f"Cantidad '{dataProvider[6]}' ingresado en el formulario.")

            comentarios = driver.find_element(By.XPATH, '//*[@id="comentarios"]')
            comentarios.send_keys(dataProvider[7])
            logging.info(f"Comentarios '{dataProvider[7]}' ingresado en el formulario.")

            time.sleep(2)
            screenshot_path = os.path.join(carpetaEvidencias, 'Formulario_crear_producto.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot del formulario de creación de cliente.")
            
            botonSubmit = driver.find_element(By.XPATH, '/html/body/form/button')
            #botonSubmit.click()
            logging.info("Botón 'Submit' localizado y preparado para clic.")
            
            
            # Registrar éxito
            logging.info("Prueba completada exitosamente.")
            tupla=(
                "Ingresar producto",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login hasta crear un producto con todos sus datos",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)            


        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
                        # Registrar éxito
            logging.info("Prueba completada exitosamente.")
            tupla=(
                "Ingresar producto",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login hasta crear un producto con todos sus datos",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla) 
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e

# Ejecutar la prueba
IngresarProducto()




