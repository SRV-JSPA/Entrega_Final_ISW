import time
import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class CrearPedido:
    def __init__(self):
        lista = login().inicioSistema('Crear pedido', 'crearPedido')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot en la carpeta
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso al sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")

            # Interacción con la página del menú principal
            botonPedidos = driver.find_element(By.XPATH, "//a[@href='/pedidos']")
            botonPedidos.click()
            logging.info("Botón 'Pedidos' clicado.")

            botonNuevoPedido = driver.find_element(By.XPATH, "/html/body/div[3]/div[1]/a")
            botonNuevoPedido.click()
            logging.info("Botón 'Crear Nuevo Pedido' clicado.")

            botonCliente = driver.find_element(By.XPATH, '//*[@id="cliente"]')
            botonCliente.send_keys(dataProvider[7])
            logging.info(f"Cliente '{dataProvider[7]}' ingresado en el formulario.")

            botonProducto = driver.find_element(By.XPATH, '//*[@id="producto"]')
            botonProducto.send_keys(dataProvider[2])
            logging.info(f"Producto '{dataProvider[2]}' ingresado en el formulario.")

            botonCantidad = driver.find_element(By.XPATH, '//*[@id="cantidad"]')
            botonCantidad.send_keys(dataProvider[3])
            logging.info(f"Cantidad '{dataProvider[3]}' ingresado en el formulario.")

            botonAgregar = driver.find_element(By.XPATH, "/html/body/form/div[2]/div/div/div[3]/button")
            botonAgregar.click()
            logging.info("Botón 'Agregar al carrito' clicado.")

            botonFechaE = driver.find_element(By.XPATH, '//*[@id="fechaEntrega"]')
            botonFechaE.send_keys(dataProvider[4])
            logging.info(f"Fecha para entregar '{dataProvider[4]}' ingresada en el formulario.")

            botonFechaR = driver.find_element(By.XPATH, '//*[@id="fechaRecoger"]')
            botonFechaR.send_keys(dataProvider[5])
            logging.info(f"Fecha para recoger '{dataProvider[5]}' ingresada en el formulario.")

            botonComentario = driver.find_element(By.XPATH, '//*[@id="comentarios"]')
            botonComentario.send_keys(dataProvider[6])
            logging.info(f"Comentario '{dataProvider[6]}' ingresado en el formulario.")

            time.sleep(2)

            screenshot_path = os.path.join(carpetaEvidencias, 'FormularioPedido.png')
            driver.get_screenshot_as_file(screenshot_path)

            logging.info("Screenshot de Pedido creado")

            botonCrear = driver.find_element(By.XPATH, "/html/body/form/button")
            botonCrear.click()
            logging.info("Botón 'Crear Pedido' clicado.")

            logging.info("Prueba finalizada con éxito")

        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e
        
# Ejecutar la prueba
CrearPedido()