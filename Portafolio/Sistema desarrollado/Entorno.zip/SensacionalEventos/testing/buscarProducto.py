import time
from core.dbTesting import crear_nueva_prueba_bd
import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class BuscarProducto:
    def __init__(self):
        lista = login().inicioSistema('Buscar Producto', 'buscarProducto')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot en la carpeta
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso al sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")


            botonClientes=driver.find_element(By.XPATH,"//a[@href='/inventario']")
            botonClientes.click()
            
            screenshot_path = os.path.join(carpetaEvidencias, 'Pagina de inventario.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Se ingresa a la pagina de inventario")
            
            WebDriverWait(driver,10).until(
                EC.presence_of_element_located((By.XPATH,"//*[@id='searchProduct']"))
            )
            
            inputSearch=driver.find_element(By.XPATH,"//*[@id='searchProduct']")
            inputSearch.send_keys(dataProvider[2])
            
            time.sleep(2)
            
            screenshot_path = os.path.join(carpetaEvidencias, 'Producto buscado.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Se toma screenshot del producto encontrado")
                        
            tupla=(
                "Buscar producto",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se busca y encuentra un producto",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)
            # Registrar éxito
            logging.info("Prueba completada exitosamente.")
        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            tupla=(
                "Buscar producto",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se busca y encuentra un producto",
                "Exitoso",
                "Fallido"
            )
            crear_nueva_prueba_bd(tupla)
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e

# Ejecutar la prueba
BuscarProducto()