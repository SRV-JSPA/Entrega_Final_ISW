from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import csv
import core.TestClass 


class initTest:
    def __init__(self):
        self.contadorScreenShots=0
        self.driver=webdriver.Chrome()
        
    def inicialCall(self):
        self.driver.get('http://127.0.0.1:5000')
        return self.driver
    def abrirDataProvider(self,nombre):
        ruta = "dataProviders/"+str(nombre) + ".csv"

        # Leer el contenido del archivo csv y eliminar la primera fila
        with open(ruta, mode='r', newline='', encoding='utf-8') as infile:
            reader = csv.reader(infile)
            data = list(reader)[1:]  # Esto elimina la primera fila
        return data
 


    

   