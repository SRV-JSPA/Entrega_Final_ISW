import time
import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
from core.dbTesting import crear_nueva_prueba_bd
import logging

class EditarCliente:
    def __init__(self):
        lista = login().inicioSistema('Editar Cliente', 'editarCliente')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot en la carpeta
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso al sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")

            # Interacción con la página del menú principal
            botonClientes = driver.find_element(By.XPATH, "//a[@href='/clientes']")
            botonClientes.click()
            logging.info("Botón 'Clientes' clicado.")

            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/crear_cliente']"))
            )
            logging.info("Vista de clientes cargada.")

            # Guardar el screenshot en la carpeta
            screenshot_path = os.path.join(carpetaEvidencias, 'Vista de clientes.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de la vista de clientes.")

            botonEditarCliente = driver.find_element(By.XPATH, "/html/body/table/tbody/tr[1]/td[6]/button")
            botonEditarCliente.click()
            logging.info("Botón 'Editar Cliente' clicado.")

            # Interacción con el formulario de creación de clientes
            nombre = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='nombre']"))
            )
            nombre.clear()
            nombre.send_keys(dataProvider[2])
            logging.info(f"Nombre '{dataProvider[2]}' ingresado en el formulario.")

            apellido = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "input[name='apellido']"))
            )
            apellido.clear()
            apellido.send_keys(dataProvider[3])
            logging.info(f"Apellido '{dataProvider[3]}' ingresado en el formulario.")

            time.sleep(2)
            screenshot_path = os.path.join(carpetaEvidencias, 'Formulario_editar_cliente.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot del formulario de edicion de cliente.")
            
            botonSubmit = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "form button[type='submit']"))
            )
            botonSubmit.click()
            logging.info("Botón 'Submit' localizado y preparado para clic.")
            tupla=(
                "Editar cliente",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se crea un edite un cliente",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)
            # Registrar éxito
            logging.info("Prueba completada exitosamente.")
        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            tupla=(
                "Editar cliente",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se crea un edite un cliente",
                "Exitoso",
                "Fallido"
            )
            crear_nueva_prueba_bd(tupla)            
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e

# Ejecutar la prueba
#EditarCliente()
