
import core.initTest as it
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import core.TestClass as Test
from selenium.webdriver.support import expected_conditions as EC
import os

class login:
    def __init__(self):
        self.i = it.initTest()
        self.driver = self.i.inicialCall()
        self.test=Test.TestClassInfo()
    def inicioSistema(self,nombrePrueba,nombreDataProvier):
        self.test.set_nombrePrueba("PruebasEjecutadas/"+nombrePrueba)
        self.test.set_dataProvider(nombreDataProvier)
        dp=self.i.abrirDataProvider(nombreDataProvier)[0]
        user=dp[0]
        passw=dp[1]
        # Login
        elementoUser = WebDriverWait(self.driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//*[@id="username"]'))
        )
        elementoUser.send_keys(user)

        elementoPass = self.driver.find_element(By.XPATH, '//*[@id="password"]')
        elementoPass.send_keys(passw)

        botonLogin = self.driver.find_element(By.XPATH, '/html/body/div/div/div/div/div[2]/form/button')
        
        
        
        
        carpetaEvidencias = "PruebasEjecutadas/"+nombrePrueba
        
        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Guardar el screenshot en la carpeta
        screenshot_path = os.path.join(carpetaEvidencias, 'Login.png')
        self.driver.get_screenshot_as_file(screenshot_path)

        
        
        
        botonLogin.click()
        return [self.driver,dp,self.test]