class TestClassInfo:
    def __init__(self):
        self._nombrePrueba = ""
        self._dataProvider = ""
        self._status = ""
        
    
    # Getter for nombrePrueba
    def get_nombrePrueba(self):
        return self._nombrePrueba
    
    # Setter for nombrePrueba
    def set_nombrePrueba(self, value):
        self._nombrePrueba = value
    
    # Getter for dataProvider
    def get_dataProvider(self):
        return self._dataProvider
    
    # Setter for dataProvider
    def set_dataProvider(self, value):
        self._dataProvider = value
    
    # Getter for status
    def get_status(self):
        return self._status
    
    # Setter for status
    def set_status(self, value):
        self._status = value

