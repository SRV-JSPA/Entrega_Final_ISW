import time
import core.initTest as it
from core.dbTesting import crear_nueva_prueba_bd
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class EliminarCliente:
    def __init__(self, nombre_cliente):
        lista = login().inicioSistema('Eliminar Cliente', 'eliminarCliente')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot de ingreso al sitio
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso_al_sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")

            # Interacción con la página del menú principal
            botonClientes = driver.find_element(By.XPATH, "//a[@href='/clientes']")
            botonClientes.click()
            logging.info("Botón 'Clientes' clicado.")

            # Espera a que la lista de clientes cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//table"))
            )
            logging.info("Lista de clientes cargada.")

            # Buscar la fila que contiene el nombre del cliente
            filas = driver.find_elements(By.XPATH, "/html/body/table/tbody/tr")
            fila_cliente = None
            for i, fila in enumerate(filas, start=1):
                nombre_xpath = f"/html/body/table/tbody/tr[{i}]/td[2]"
                nombre_elemento = driver.find_element(By.XPATH, nombre_xpath)
                if nombre_elemento.text == nombre_cliente:
                    fila_cliente = i
                    break

            if fila_cliente is not None:
                # Capturar screenshot antes de eliminar el cliente
                screenshot_antes_eliminar_path = os.path.join(carpetaEvidencias, f'Cliente_{nombre_cliente}_Antes_de_Eliminar.png')
                driver.get_screenshot_as_file(screenshot_antes_eliminar_path)
                logging.info(f"Capturado screenshot antes de eliminar cliente '{nombre_cliente}'.")

                # Construir XPath para el botón de eliminar del cliente
                eliminar_xpath = f"/html/body/table/tbody/tr[{fila_cliente}]/td[6]/a"
                botonEliminar = driver.find_element(By.XPATH, eliminar_xpath)
                botonEliminar.click()
                logging.info(f"Cliente '{nombre_cliente}' eliminado.")

                # Esperar a que la eliminación se refleje en la UI (puedes ajustar el tiempo según sea necesario)
                time.sleep(2)

                # Capturar screenshot después de eliminar el cliente
                screenshot_despues_eliminar_path = os.path.join(carpetaEvidencias, f'Cliente_{nombre_cliente}_Eliminado.png')
                driver.get_screenshot_as_file(screenshot_despues_eliminar_path)
                logging.info(f"Capturado screenshot después de eliminar cliente '{nombre_cliente}'.")
            else:
                logging.warning(f"Cliente '{nombre_cliente}' no encontrado.")
                
            tupla=(
                "Eliminar cliente",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se elimine un cliente",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)

        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            tupla=(
                "Eliminar cliente",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se elimine un cliente",
                "Exitoso",
                "Fallido"
            )
            crear_nueva_prueba_bd(tupla) 
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e

# Ejecutar la prueba para un cliente específico
#nombre_cliente = "hola"
#EliminarCliente(nombre_cliente)
