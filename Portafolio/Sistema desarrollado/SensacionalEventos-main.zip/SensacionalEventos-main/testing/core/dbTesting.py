# conexion.py
import psycopg2
from psycopg2 import Error
import os



def crear_conexion():
    try:
        # Conexión a la base de datos PostgreSQL
        conexion = psycopg2.connect(
            user="postgres",
            password="pelu1503",
            host="localhost",
            port="5432",
            database="sensacionaleventosdb"
        )
        return conexion
    except (Exception, Error) as error:
        print("Error al conectarse a la base de datos:", error)

def ejecutar_script(conexion, script_file):
    cursor = None
    try:
        # Abre el archivo del script y ejecuta las declaraciones SQL
        with open(script_file, 'r') as file:
            script = file.read()
            cursor = conexion.cursor()
            cursor.execute(script)
            conexion.commit()
            print("Script ejecutado correctamente.")
    except (Exception, Error) as error:
        print("Error al ejecutar el script:", error)
    finally:
        if cursor:
            cursor.close()
        if conexion:
            conexion.close()
            print("Conexion cerrada.")

###################################################################
#                         TESTING QA                              #
###################################################################

def crear_nueva_prueba_bd(nueva_prueba):
    try:
        conexion = crear_conexion()
        with conexion:
            with conexion.cursor() as cursor:
                query = """
                INSERT INTO prueba (
                    nombreprueba, alcanceprueba, idTipoPrueba, descripcionPrueba, estatusesperado, estatusReal
                ) VALUES (%s, %s, %s, %s, %s, %s)
                """
                cursor.execute(query, nueva_prueba)
                conexion.commit()
                return True
    except (Exception, Error) as error:
        print("Error al insertar la nueva prueba:", error)
        return False
def obtener_todas_las_pruebas_bd():
    try:
        conexion = crear_conexion()
        with conexion:
            with conexion.cursor() as cursor:
                cursor.execute("SELECT * FROM prueba;")
                pruebas = cursor.fetchall()
                return pruebas
    except (Exception, Error) as error:
        print("Error al obtener las pruebas:", error)
        return []
def obtener_prueba_por_id_bd(id_prueba):
    try:
        conexion = crear_conexion()
        with conexion:
            with conexion.cursor() as cursor:
                cursor.execute("SELECT * FROM prueba WHERE id = %s;", (id_prueba,))
                prueba = cursor.fetchone()
                if prueba:
                    return {
                        "id": prueba[0],
                        "nombreprueba": prueba[1],
                        "alcanceprueba": prueba[2],
                        "idTipoPrueba": prueba[3],
                        "descripcionPrueba": prueba[4],
                        "estatusesperado": prueba[5],
                        "estatusReal": prueba[6]
                    }
                else:
                    return None
    except (Exception, Error) as error:
        print("Error al obtener la prueba por ID:", error)
        return None

def editar_prueba_bd(id_prueba, nuevos_datos):
    try:
        conexion = crear_conexion()
        with conexion:
            with conexion.cursor() as cursor:
                query = """
                UPDATE prueba SET
                    nombreprueba = %s,
                    alcanceprueba = %s,
                    idTipoPrueba = %s,
                    descripcionPrueba = %s,
                    estatusesperado = %s,
                    estatusReal = %s
                WHERE id = %s;
                """
                cursor.execute(query, (
                    nuevos_datos["nombreprueba"],
                    nuevos_datos["alcanceprueba"],
                    nuevos_datos["idTipoPrueba"],
                    nuevos_datos["descripcionPrueba"],
                    nuevos_datos["estatusesperado"],
                    nuevos_datos["estatusReal"],
                    id_prueba
                ))
                conexion.commit()
                return cursor.rowcount > 0
    except (Exception, Error) as error:
        print("Error al actualizar la prueba:", error)
        return False

def eliminar_prueba_bd(id_prueba):
    try:
        conexion = crear_conexion()
        with conexion:
            with conexion.cursor() as cursor:
                cursor.execute("DELETE FROM prueba WHERE id = %s;", (id_prueba,))
                conexion.commit()
                return cursor.rowcount > 0
    except (Exception, Error) as error:
        print("Error al eliminar la prueba:", error)
        return False


if __name__ == "__main__":
    conexion = crear_conexion()
    if conexion:
        ejecutar_script(conexion, "schema.sql")