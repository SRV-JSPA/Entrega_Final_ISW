import matplotlib.pyplot as plt
from collections import Counter
from core.dbTesting import obtener_todas_las_pruebas_bd
import os
class Dashboard:
    def __init__(self):
        print("Inicializando Dashboard...")
        self.data = self.obtener_datos()
        if self.data:
            print(f"Datos obtenidos: {len(self.data)} registros encontrados.")
        else:
            print("No se obtuvieron datos.")
        self.visualizar_datos()

    def obtener_datos(self):
        try:
            data = obtener_todas_las_pruebas_bd()
            print("Datos obtenidos correctamente desde la base de datos.")
            return data
        except Exception as e:
            print(f"Error al obtener los datos: {e}")
            return []
    def visualizar_datos(self):
        if not self.data:
            print("No hay datos para visualizar.")
            return

        # Contar pruebas exitosas y fallidas
        resultados = [item[-1] for item in self.data]
        conteo_resultados = Counter(resultados)
        print(f"Conteo de resultados: {conteo_resultados}")

        # Gráfico de pie para pruebas fallidas y exitosas
        tipos_prueba = [item[1] for item in self.data]
        conteo_tipos = Counter(tipos_prueba)
        print(f"Conteo de tipos de prueba: {conteo_tipos}")

        # Gráfico 1: Número de pruebas por área (FrontEnd, serverSide)
        areas = [item[2] for item in self.data]
        conteo_areas = Counter(areas)
        print(f"Conteo de áreas: {conteo_areas}")

        # Gráfico 2: Estado de pruebas (número de veces que se repitió cada estado)
        estados_pruebas = [(item[1], item[-1]) for item in self.data]
        conteo_estados = Counter(estados_pruebas)
        labels, counts = zip(*conteo_estados.items())
        labels = ['{} - {}'.format(label[0], label[1]) for label in labels]
        print(f"Conteo de estados de prueba: {conteo_estados}")

        # Gráfico 3: Cantidad de pruebas ejecutadas sobre 100
        total_pruebas = len(self.data)

        # Configurar el layout del tablero general
        fig, axs = plt.subplots(3, 2, figsize=(15, 15))
        axs[0, 0].pie(conteo_resultados.values(), labels=conteo_resultados.keys(), autopct='%1.1f%%', startangle=90)
        axs[0, 0].set_title('Distribución de Pruebas Exitosas y Fallidas')
        
        axs[0, 1].bar(conteo_tipos.keys(), conteo_tipos.values(), color='skyblue')
        axs[0, 1].set_xlabel('Tipo de Prueba')
        axs[0, 1].set_ylabel('Número de Pruebas')
        axs[0, 1].set_title('Número de Pruebas por Tipo de Prueba')
        axs[0, 1].set_xticks(range(len(conteo_tipos.keys())))
        axs[0, 1].set_xticklabels(conteo_tipos.keys(), rotation=45)

        axs[1, 0].bar(conteo_areas.keys(), conteo_areas.values(), color='lightgreen')
        axs[1, 0].set_xlabel('Área')
        axs[1, 0].set_ylabel('Número de Pruebas')
        axs[1, 0].set_title('Número de Pruebas por Área')
        axs[1, 0].set_xticks(range(len(conteo_areas.keys())))
        axs[1, 0].set_xticklabels(conteo_areas.keys(), rotation=45)

        axs[1, 1].bar(labels, counts, color='coral')
        axs[1, 1].set_xlabel('Tipo de Prueba y Estado')
        axs[1, 1].set_ylabel('Número de Pruebas')
        axs[1, 1].set_title('Estado de Pruebas por Tipo de Prueba')
        axs[1, 1].set_xticks(range(len(labels)))
        axs[1, 1].set_xticklabels(labels, rotation=90)

        axs[2, 0].barh(['Pruebas Ejecutadas'], [total_pruebas], color='blue')
        axs[2, 0].set_xlim(0, 100)
        axs[2, 0].set_xlabel('Cantidad de Pruebas')
        axs[2, 0].set_title('Progreso de Pruebas Ejecutadas sobre 100')

        # Ocultar el subplot vacío
        fig.delaxes(axs[2, 1])

        # Ajustar el espaciado
        plt.tight_layout()

        # Guardar el tablero completo
        base_path = os.getcwd()
        filepath = os.path.join(base_path, 'tablero_completo.png')
        fig.savefig(filepath)
        print(f"Tablero guardado en: {filepath}")
        plt.show()

# Crear una instancia de la clase Dashboard para ejecutar el código
app = Dashboard()

