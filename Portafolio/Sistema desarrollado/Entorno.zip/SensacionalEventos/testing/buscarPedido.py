import time
from core.dbTesting import crear_nueva_prueba_bd
import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class BuscarPedido:
    def _init_(self):
        lista = login().inicioSistema('Buscar Pedido', 'buscarPedido')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot en la carpeta
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso al sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/pedidos']"))
            )
            logging.info("Página del menú principal cargada.")

            # Interacción con la página del menú principal
            botonPedidos = driver.find_element(By.XPATH, "//a[@href='/pedidos']")
            botonPedidos.click()
            logging.info("Botón 'Pedidos' clicado.")
            
            
            buscarPedidos= driver.find_element(By.XPATH,"//*[@id='searchOrder']")
            buscarPedidos.send_keys(dataProvider[2])
            logging.info(f"Pedido '{dataProvider[2]}' buscado.")
            
            
            screenshot_path = os.path.join(carpetaEvidencias, 'Buscar pedido.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de búsqueda de pedido.")
            
            logging.info("Prueba completada exitosamente.")
            tupla=(
                "Buscar pedido",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se busca y encuentra un pedido",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)

           
            
            
        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            tupla=(
                "Buscar pedido",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se busca y encuentra un pedido",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e

# Ejecutar la prueba
BuscarPedido()