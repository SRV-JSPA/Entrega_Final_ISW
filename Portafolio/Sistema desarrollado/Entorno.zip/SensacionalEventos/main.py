import webbrowser
from flask_app import app
import threading

def abrir_navegador():
    webbrowser.open_new("http://127.0.0.1:5000")
    
if __name__=="__main__":
    threading.Timer(1,abrir_navegador).start()
    app.run(debug=True)