import time

from core.dbTesting import crear_nueva_prueba_bd

import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class EliminarProducto:
    def __init__(self, nombre_producto):
        lista = login().inicioSistema('Eliminar Producto', 'eliminarProducto')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot de ingreso al sitio
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso_al_sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")

            # Interacción con la página del menú principal
            botonInventario = driver.find_element(By.XPATH, "//a[@href='/inventario']")
            botonInventario.click()
            logging.info("Botón 'Inventario' clicado.")
            
            # Espera a que la lista de inventario cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//table"))
            )
            logging.info("Lista de inventario cargada.")
            
            # Buscar la fila que contiene el nombre del producto
            filas = driver.find_elements(By.XPATH, "/html/body/table/tbody/tr")
            fila_producto = None
            for i, fila in enumerate(filas, start=1):
                nombre_xpath = f"/html/body/table/tbody/tr[{i}]/td[1]"
                nombre_elemento = driver.find_element(By.XPATH, nombre_xpath)
                if nombre_elemento.text == nombre_producto:
                    fila_producto = i
                    break
                
                
                
            if fila_producto is not None:
                # Capturar screenshot antes de eliminar el producto
                screenshot_antes_eliminar_path = os.path.join(carpetaEvidencias, f'Producto_{nombre_producto}_Antes_de_Eliminar.png')
                driver.get_screenshot_as_file(screenshot_antes_eliminar_path)
                logging.info(f"Capturado screenshot antes de eliminar producto '{nombre_producto}'.")
                
                # Construir XPath para el botón de eliminar del producto
                eliminar_xpath = f"/html/body/table/tbody/tr[{fila_producto}]/td[7]/a"
                botonEliminar = driver.find_element(By.XPATH, eliminar_xpath)
                botonEliminar.click()
                logging.info(f"Producto '{nombre_producto}' eliminado.")
                
                # Esperar a que la eliminación se refleje en la UI
                time.sleep(2)
                
                # Capturar screenshot después de eliminar el producto
                screenshot_despues_eliminar_path = os.path.join(carpetaEvidencias, f'Producto_{nombre_producto}_Eliminado.png')
                driver.get_screenshot_as_file(screenshot_despues_eliminar_path)
                logging.info(f"Capturado screenshot después de eliminar producto '{nombre_producto}'.")
            else:
                logging.warning(f"Producto '{nombre_producto}' no encontrado.")
            tupla=(
                "Eliminar producto",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se elimine un producto",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)                

                
        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            tupla=(
                "Eliminar producto",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se elimine un producto",
                "Exitoso",
                "Fallido"
            )
            crear_nueva_prueba_bd(tupla)             

            
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e
        
# Ejecutar la prueba para un producto específico
#nombre_producto = "plato"
#EliminarProducto(nombre_producto)

nombre_producto = "plato"
EliminarProducto(nombre_producto)
