import time
from core.dbTesting import crear_nueva_prueba_bd
import core.initTest as it
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pruebaLogin import login
import os
import logging

class EliminarPedido:
    def __init__(self, nombre_pedido):
        lista = login().inicioSistema('Eliminar Pedido', 'eliminarPedido')
        driver = lista[0]
        dataProvider = lista[1]
        testData = lista[2]

        carpetaEvidencias = testData.get_nombrePrueba()

        # Crear la carpeta si no existe
        if not os.path.exists(carpetaEvidencias):
            os.makedirs(carpetaEvidencias)
        
        # Configurar el logging para guardar en carpetaEvidencias
        log_file = os.path.join(carpetaEvidencias, 'log_pruebas.log')
        logging.basicConfig(filename=log_file, level=logging.INFO, 
                            format='%(asctime)s - %(levelname)s - %(message)s')

        try:
            # Guardar el screenshot de ingreso al sitio
            screenshot_path = os.path.join(carpetaEvidencias, 'Ingreso_al_sitio.png')
            driver.get_screenshot_as_file(screenshot_path)
            logging.info("Capturado screenshot de ingreso al sitio.")

            # Espera a que la página del menú principal cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//a[@href='/clientes']"))
            )
            logging.info("Página del menú principal cargada.")
            
            # Interacción con la página del menú principal
            botonInventario = driver.find_element(By.XPATH, "//a[@href='/pedidos']")
            botonInventario.click()
            logging.info("Botón 'Pedidos' clicado.")

            # Espera a que la lista de pedidos cargue
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, "//table"))
            )
            logging.info("Lista de pedidos cargada.")

            # Buscar la fila que contiene el nombre del pedido
            filas = driver.find_elements(By.XPATH, "/html/body/div[2]/div/table/tbody/tr")
            fila_pedido = None
            for i, fila in enumerate(filas, start=1):
                nombre_xpath = f"/html/body/div[2]/div/table/tbody/tr[{i}]/td[2]"
                nombre_elemento = driver.find_element(By.XPATH, nombre_xpath)
                if nombre_elemento.text == nombre_pedido:
                    fila_pedido = i
                    break

            if fila_pedido is not None:
                # Capturar screenshot antes de eliminar el pedido
                screenshot_antes_eliminar_path = os.path.join(carpetaEvidencias, f'Pedido_{nombre_pedido}_Antes_de_Eliminar.png')
                driver.get_screenshot_as_file(screenshot_antes_eliminar_path)
                logging.info(f"Capturado screenshot antes de eliminar pedido '{nombre_pedido}'.")
                 # Construir XPath para el botón de eliminar del pedido
                eliminar_xpath = f"/html/body/div[2]/div/table/tbody/tr[{fila_pedido}]/td[8]/div/a[2]"
                botonEliminar = driver.find_element(By.XPATH, eliminar_xpath)
                botonEliminar.click()
                logging.info(f"Pedido '{nombre_pedido}' eliminado.")

                # Esperar a que la eliminación se refleje en la UI (puedes ajustar el tiempo según sea necesario)
                time.sleep(2)

                # Capturar screenshot después de eliminar el pedido
                screenshot_despues_eliminar_path = os.path.join(carpetaEvidencias, f'Pedido_{nombre_pedido}_Eliminado.png')
                driver.get_screenshot_as_file(screenshot_despues_eliminar_path)
                logging.info(f"Capturado screenshot después de eliminar pedido '{nombre_pedido}'.")

            else:
                logging.warning(f"Pedido '{nombre_pedido}' no encontrado.")
            tupla=(
                "Eliminar pedido",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se elimine un pedido",
                "Exitoso",
                "Exitoso"
            )
            crear_nueva_prueba_bd(tupla)

        except Exception as e:
            # Guardar el screenshot en caso de error
            screenshot_path = os.path.join(carpetaEvidencias, 'Error.png')
            driver.get_screenshot_as_file(screenshot_path)
            tupla=(
                "Eliminar pedido",
                "FrontEnd, serverSide",
                "4",
                "Tiene que realizar el proceso desde el login, hasta que se elimine un pedido",
                "Exitoso",
                "Fallido"
            )
            crear_nueva_prueba_bd(tupla)   
            
            # Registrar el error
            logging.error(f"Error durante la prueba: {e}")
            raise e

# Ejecutar la prueba para un pedido específico
#nombre_pedido = "vaso---3,mantel---30,plato---3,"
#EliminarPedido(nombre_pedido)
