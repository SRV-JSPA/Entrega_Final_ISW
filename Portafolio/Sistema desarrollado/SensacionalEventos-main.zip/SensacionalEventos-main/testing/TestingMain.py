import buscarCliente, buscarPedido, buscarProducto, crearPedido, editarcliente, eliminarCliente, eliminarPedido, eliminarProducto, ingresarCliente, ingresarProducto
import time

class TestingMain:
    def __init__(self):
        self.inicializar()

    def inicializar(self):
        # buscarCliente
        buscarCliente.BuscarCliente()
        self.tiempoDormido(2)

        # buscarPedido
        buscarPedido.BuscarPedido()
        self.tiempoDormido(2)

        # buscarProducto
        buscarProducto.BuscarProducto()
        self.tiempoDormido(2)

        # crearPedido
        crearPedido.CrearPedido()
        self.tiempoDormido(2)

        # editarCliente
        editarcliente.EditarCliente()
        self.tiempoDormido(2)

        # eliminarCliente
        nombre = "Rodrigo"
        eliminarCliente.EliminarCliente(nombre)
        self.tiempoDormido(2)

        # eliminarPedido
        nombre_pedido = "vaso---3,mantel---30,plato---3,"
        eliminarPedido.EliminarPedido(nombre_pedido)
        self.tiempoDormido(2)

        # eliminarProducto
        nombre_producto = "plato"
        eliminarProducto.EliminarProducto(nombre_producto)
        self.tiempoDormido(2)

        # ingresarCliente
        ingresarCliente.IngresarCliente()
        self.tiempoDormido(2)

        # ingresarProducto
        ingresarProducto.IngresarProducto()
        self.tiempoDormido(2)

    def tiempoDormido(self, segundos):
        time.sleep(segundos)

app = TestingMain()
